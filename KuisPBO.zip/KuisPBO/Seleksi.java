package KuisPBO;

public interface Seleksi {
        public double hitungNilaiTotal();
        public String penentuanKelolosan();
    }
