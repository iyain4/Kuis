package KuisPBO;

public class inputData {
        String nama,usia;
        double nilaiStruktur, nilaiVisual ,nilaiDesign;

        public inputData(String usia, String nama, double nilaiStruktur, double nilaiVisual, double nilaiDesign) {
            this.usia = usia;
            this.nama = nama;
            this.nilaiStruktur = nilaiStruktur;
            this.nilaiVisual = nilaiVisual;
            this.nilaiDesign = nilaiDesign;
        }

    }
