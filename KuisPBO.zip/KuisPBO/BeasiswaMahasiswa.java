package KuisPBO;

public class BeasiswaMahasiswa extends inputDataMahasiswa implements Seleksi{
    public BeasiswaMahasiswa(String usia, String nama, double nilaiKonten, double nilaiRelevansi, double nilaiProblemSolving) {
        super(usia, nama, nilaiKonten, nilaiRelevansi, nilaiProblemSolving);
    }

    public void inputnilaiKonten(double nilaiKonten) {
        this.nilaiKonten = nilaiKonten;
    }
    public void inputnilaiRelevansi(double nilaiRelevansi) {
        this.nilaiRelevansi = nilaiRelevansi;
    }
    public void inputnilaiProblemSolving(double nilaiProblemSolving) {
        this.nilaiProblemSolving = nilaiProblemSolving;
    }

    @Override
    public double hitungNilaiTotal() {
        return (0.6 * super.nilaiKonten) + (0.25 * super.nilaiRelevansi) + (0.15 * super.nilaiProblemSolving);
    }

    @Override
    public String penentuanKelolosan() {
        if(this.hitungNilaiTotal() >= 87.5)
        return "LULUS\nSelamat kepada " + this.nama + ", telah DITERIMA dalam Program Beasiswa Mahasiswa\n";
        else
        return "GAGAL\nMohon maaf kepada  " + this.nama + " telah DITOLAK dalam Program Beasiswa Mahasiswa\n";
    }

}
