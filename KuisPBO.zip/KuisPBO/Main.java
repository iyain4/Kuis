package KuisPBO;

import java.util.Scanner;

public class Main{
    public static void main(String[] args) {
        try{
            int coba = 1;
            do{
                Scanner input = new Scanner(System.in);
                System.out.println("Pendaftaran Beasiswa PT.Benang");
                System.out.println("1. Beasiswa Pelajar");
                System.out.println("2. Beasiswa Mahasiswa");
                System.out.print("Masukan Pilihan : ");
                int menu = input.nextInt();

                switch(menu){
                    case 1:
                    {
                        Scanner inputKalimat = new Scanner(System.in).useDelimiter("\n");
                        System.out.print("Masukkan nama \t\t: ");
                        String nama = inputKalimat.next();
                        System.out.print("\n\nMasukkan usia \t\t: ");
                        String usia = input.next();
                        System.out.print("Masukkan nilai Struktur \t\t: ");
                        double struktur = input.nextDouble();
                        System.out.print("Masukkan nilai Visual \t\t: ");
                        double visual = input.nextDouble();
                        System.out.print("Masukkan nilai Design \t: ");
                        double design = input.nextDouble();

                        BeasiswaPelajar BeasiswaPelajar = new BeasiswaPelajar(usia, nama, struktur, visual, design);
                        int ulang = 1;
                        do{
                            System.out.println("\n\nMenu : ");
                            System.out.println("1. Tampilkan");
                            System.out.println("2. Edit");
                            System.out.println("3. Exit");
                            System.out.print("Masukan Pilihan : ");
                            int submenu = input.nextInt();

                            switch(submenu){
                                case 1:
                                    System.out.println("Nilai Akhir : " + BeasiswaPelajar.hitungNilaiTotal());
                                    System.out.println("Keterangan : " + BeasiswaPelajar.penentuanKelolosan());
                                    break;

                                case 2:
                                    System.out.print("Masukkan nilai Struktur \t\t: ");
                                    BeasiswaPelajar.inputnilaiStruktur(input.nextDouble());
                                    System.out.print("Masukkan nilai Visual \t\t: ");
                                    BeasiswaPelajar.inputnilaiVisual(input.nextDouble());
                                    System.out.print("Masukkan nilai Design \t: ");
                                    BeasiswaPelajar.inputnilaiDesign(input.nextDouble());
                                    break;
                                case 3:
                                    ulang = 0;
                                    break;
                                default:
                                    System.out.println("Input yang Anda masukan salah, silahkan ulangi kembali!");
                            }
                        } while(ulang != 0);
                        coba = 0;
                        break;
                    }
                    case 2:
                    {
                        Scanner inputKalimat = new Scanner(System.in).useDelimiter("\n");
                        System.out.print("Masukkan nama \t\t: ");
                        String nama = inputKalimat.next();
                        System.out.print("\n\nMasukkan usia \t\t: ");
                        String usia = input.next();
                        System.out.print("Masukkan nilai Struktur \t\t: ");
                        double konten = input.nextDouble();
                        System.out.print("Masukkan nilai Visual \t\t: ");
                        double relevansi = input.nextDouble();
                        System.out.print("Masukkan nilai Design \t: ");
                        double problemSolving = input.nextDouble();

                        BeasiswaMahasiswa BeasiswaMahasiswa  = new BeasiswaMahasiswa (usia, nama, konten, relevansi, problemSolving);
                        int ulang = 1;
                        do{
                            System.out.println("\n\nMenu : ");
                            System.out.println("1. Tampilkan");
                            System.out.println("2. Edit");
                            System.out.println("3. Exit");
                            System.out.print("Masukan Pilihan : ");
                            int submenu = input.nextInt();

                            switch(submenu){
                                case 1:
                                    System.out.println("Nilai Akhir : " + BeasiswaMahasiswa .hitungNilaiTotal());
                                    System.out.println("Keterangan : " +  BeasiswaMahasiswa .penentuanKelolosan());
                                    break;
                                case 2:

                                    System.out.print("Masukkan nilai Struktur Anda\t\t: ");
                                    BeasiswaMahasiswa.inputnilaiKonten(input.nextDouble());
                                    System.out.print("Masukkan nilai Visual Anda\t\t: ");
                                    BeasiswaMahasiswa.inputnilaiRelevansi(input.nextDouble());
                                    System.out.print("Masukkan nilai Design Anda\t: ");
                                    BeasiswaMahasiswa.inputnilaiProblemSolving(input.nextDouble());
                                    break;
                                case 3:
                                    ulang = 0;
                                    break;
                                default:
                                    System.out.println("Input yang Anda masukan salah, silahkan ulangi kembali!");
                            }
                        } while(ulang != 0);
                        coba = 0;
                        break;
                    }
                    default:
                        System.out.println("Input yang Anda masukan salah, silahkan ulangi kembali!");
                }
            }while(coba != 0);
        } catch(Exception e){
            System.out.println("Error : " + e.getMessage());
        }
    }
}