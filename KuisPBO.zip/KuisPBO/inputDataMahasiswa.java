package KuisPBO;

public class inputDataMahasiswa{
    String nama,usia;
    double nilaiKonten, nilaiRelevansi ,nilaiProblemSolving;

    public inputDataMahasiswa(String usia, String nama, double nilaiKonten, double nilaiRelevansi, double nilaiProblemSolving) {
        this.usia = usia;
        this.nama = nama;
        this.nilaiKonten = nilaiKonten;
        this.nilaiRelevansi = nilaiRelevansi;
        this.nilaiProblemSolving = nilaiProblemSolving;
    }}