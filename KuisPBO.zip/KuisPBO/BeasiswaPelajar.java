package KuisPBO;
public class BeasiswaPelajar extends inputData implements Seleksi{
    public BeasiswaPelajar(String usia, String nama, double nilaiStruktur, double nilaiVisual, double nilaiDesign) {
        super(usia, nama, nilaiStruktur, nilaiVisual, nilaiDesign);
    }

    public void inputnilaiStruktur(double nilaiStruktur) {
        this.nilaiStruktur = nilaiStruktur;
    }
    public void inputnilaiVisual(double nilaiVisual) {
        this.nilaiVisual = nilaiVisual;
    }
    public void inputnilaiDesign(double nilaiDesign) {
        this.nilaiDesign = nilaiDesign;
    }

    @Override
    public double hitungNilaiTotal() {
        return (0.5 * super.nilaiStruktur) + (0.2 * super.nilaiVisual) + (0.3 * super.nilaiDesign);
    }

    @Override
    public String penentuanKelolosan() {
        if(this.hitungNilaiTotal() >= 87.5)
        return "LULUS\nSelamat kepada " + this.nama + ", telah DITERIMA dalam Program Beasiswa Pelajar\n";
        else
        return "GAGAL\nMohon maaf kepada  " + this.nama + " telah DITOLAK dalam Program Beasiswa Pelajar\n";
    }

}
